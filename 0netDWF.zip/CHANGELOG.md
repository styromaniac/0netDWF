### ZeroNet Webhosting Fileshare 0NetDWF 24.8.23 (2023-08-24) Rev6000
 - Bigfile plugin autodownload bigfile size limit default value are 2500MB
 - Added GeoLite2-City.mmdb to data folder default
 - Auto detect the most widely used optional file types when created new zites
 - Start page are added to the client
 - Removed untrusted centralized DNS provider support, and malfunctioning user sized blocklist support (global censor tool)
 - Default site size limit in MB value are 1000MB
 - Multiuser plugin public proxy/webserver mod allow all zite access in the network (default) or just the zites in the server. Open MultiuserPlugin.py with a text editor for more info.
 - PeerPortChecker.py when ZeroNet opening a UPnP port in the router the hostname are discreetly using UPnP as hostname and not ZeroNet
 - Fix ReDoS in file editor (UiFileManager plugin) due to outdated codemirror
 - Updated trackers
 - Disable ip address leak when downloading geoip db in tor-only mode
 - Fixed default ssl version to be secure
 - Fixed multiuser/merger plugins interaction
 - Added 21 laguages to the client and zites: DA, DE, EN, ES, FA, FR, HU, IT, NL,  PL, PT, PT-BR,  RU, SK,  TR, UK, ZH, ZH-TW,  JP, SL, KR. Fixed missing transalations
 - Fixed Trayicon ES language
 - Removed merkletools dependency
 - Msgpack upgraded to 0.6.1
 - Fixed leak of local 0net sites to clearnet sites 
 - Fixed return value of bigfile upload post request 
 - src/main.py minor code improvements, don't fail when plugin options are provided, show help if exception is thrown early in startup,
 - Consolidate & fix open browser behaviour 
 - Keep browser process alive 
 - Drop attempts at py<3.6 compatibility
 - Improve and speed up content.json loading 
 - Allow setting permission_rules to null to forbid everything 

### ZeroNet Webhosting Fileshare 0NetDWF 21.11.23 (2023-11-21) Rev6000
- Disable third-party sites access security hole to 0net server
- Fixed detection of non-writeable start directory
- Disable port check option in Tor Always and Offline mode
- Fixed SafeRe is vulnerable to ReDoS
- Fixed UiServer.getPosted hanging in some circumstances
- Fixed some Network scalabily and performance issuses

### ZeroNet Webhosting Fileshare 0NetDWF 28.11.23 (2023-11-28) Rev6000
- Fixed console and stats plugin

### ZeroNet Webhosting Fileshare 0NetDWF 09.01.24 (2024-01-10) Rev6001
- Reduce fingerprinting information accessible to unprivileged sites 
- Reduce fingerprinting of site owner 
- Reduce fingerprinting information sent to other nodes 
- Added Favourite button in the sidebar
- Transalated sidebar optional files menu and fixed the description
- Fixed some src/Connection content updating issues integrated some wupg98 and Zeronet enhanced patches

### ZeroNet Webhosting Fileshare 0NetDWF 13.01.24 (2024-01-13) Rev6002

- Fixed starting issue when the client are running

### ZeroNet Webhosting Fileshare 0NetDWF 25.01.24 (2024-01-25) Rev6005

- Fixed spam console with failed announcements 
- Added reson to update link and some dashboard transalations.

### ZeroNet Webhosting Fileshare 0NetDWF 31.01.24 (2024-01-31) Rev6007

To use Linix and Windows Tor Update Required To update manual way using the .zip or .rar folders

- Reduce fingerprinting information: trackers
- Reduce fingerprinting information in siteInfo
- Added No logging (Except Critical) option to Level of logging to file menu
- Updated Tor expert bundle for Windows 13.0, Linux 13.09 to (using whit default Meek and Snowflake both bridges if bridges are used but you can add obfs4 bridges to core/tools/tor torrc-defaults file)
- Fixed do not hide Use Tor Bridges option in Config Page
- Fixed PeerDbPlugin.py save peer issue

### ZeroNet Webhosting Fileshare 0NetDWF 10.02.24 (2024-02-10) Rev6008

- Fixed Linux binary to detect torrc-default config file in Tor main folder and Bridges under Linux
- Added to Linux binaries core/tools/tor folder How to setup Bridge description.
- Changed SocksPort 49051 and ControlPort to 49050 from 9051 and 9050 for safety, security reasons to prevent the ZeroNet client from connecting to other Tor applications. Thus preventing unwanted IP leaks about the user from  b  another Tor client.

### ZeroNet Webhosting Fileshare 0NetDWF 21.03.24 (2024-03-21) Rev6009

- Optimized, received higher limits large file PeerMessage/FileRequestPlugin so that downloads are interrupted less often and try to download files for a longer period of time if not available at that moment. 


 

 