# ZeroNet-Background

ZeroNet plugin for running site code in background, when browser is closed. Safe.
